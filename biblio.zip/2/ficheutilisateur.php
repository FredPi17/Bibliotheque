<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bibliotheque | Accueil</title>
  <!-- Bootstrap -->
    <link href="style/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <link href="style/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="style/bootstrap.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <!-- /**Le jquery ne se trouve pas dans le download boot strap on est obligé de le récupérer enligne!*/-->
  <script src="js/bootstrap.min.js"></script>
  <style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 70%; /**Règle ta taille de carrousel /a width*/
      margin: auto;
  }
  </style>
</head>
<?php
include("include/outils.php");
include("include/livre.php");
include('include/connexion.php');

echo Menu();
if (isset($_GET["code"])) {
  $p_requete = $p_base->prepare('select nom, prenom, mail, IDutilisateur from utilisateur where utilisateur.IDutilisateur = :code ');
  $p_requete -> execute(array('code'=> $_GET["code"]));
    if ($donnees = $p_requete->fetch()){
      echo '<title>Fiche de ' . $donnees['prenom'] . ' </title>
      	<h1>Fiche de ' .  $donnees['prenom'] .' </h1><br>';

        echo '<form method="post">';
        echo '<table>';
        echo '<tr>';
        echo '<td><label for="nom">Nom :</label></td>';
        echo '<td><input type="text" name="nom" id="nom" value="' . $donnees['nom'] .'"></td>';
        echo "</tr>\n";

        echo '<tr>';
        echo '<td><label for="nom">Prenom :</label></td>';
        echo '<td><input type="text" name="prenom" id="prenom" value="' . $donnees['prenom'] .'"></td>';
        echo "</tr>\n";

        echo '<tr>';
        echo '<td><label for="nom">Email :</label></td>';
        echo '<td><input type="text" name="mail" id="mail" value="' . $donnees['mail'] .'"></td>';
        echo "</tr>\n";

      echo '<tr>';
      echo '<td></td>';
      echo '<td><input type="submit" name="modifier" value="modifier">';
      echo '<input type="submit" name="supprimer" value="supprimer"></td>';
      echo '</tr>';

      echo '<input type="hidden" name="code" value="' . $_GET["code"].'">';

      echo '</table>';
      echo '</form>';

    }
    else
      die("Eh, le Noob pas de blague");
}
 ?>
