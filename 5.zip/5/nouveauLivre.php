<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bibliotheque | Accueil</title>
  <!-- Bootstrap -->
    <link href="style/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <link href="style/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="style/bootstrap.min.css">

  </style>
</head>
<?php
session_start();
include("include/outils.php");
include("include/utilisateur.php");
echo menuConnexion();
echo Menu();

?>
<h1>Nouveau livre</h1>
<form method="post" enctype="multipart/form-data">
  <label for="isbn">ISBN</label>
    <input type="text" name="isbn" id="isbn"><br />
  <label for="titre">Titre</label>
    <input type="text" name="titre" id="titre"><br />
  <label for="resume">Résumé</label>
    <input type="text" name="resume" id="resume"><br />
  <label for="auteur">Auteur</label>
    <input type="text" name="auteur" id="auteur"><br />
  <label for="icone">Couverture du livre</label>
    <input type="file" name="icone" id="icone" /><br />
  <input type="submit" name="envoyer" value="envoyer">
</form>
<?php
if (isset($_POST['envoyer'])){
  $nom = $_POST['auteur'];
  $p_requete = $bdd->prepare('INSERT INTO auteur (Nom) VALUES (:nom)');
  $p_requete2 = $bdd->query("SELECT IDauteur FROM auteur where Nom ='. $nom .'");
  $p_requete3 = $bdd->prepare('INSERT INTO objet (image, Resume, Titre, ISBN, IDauteur ) VALUES (:img, :resume, :titre, :isbn, :code)');

  $p_requete->execute(array(
    'nom' =>$_POST['auteur']
  ));

while ($donnees = $p_requete2->fetch()) {
  $code = $donnees['IDauteur'];
}

  $p_requete3->execute(array(
    'code' => $code,
    'img' => basename($_FILES['icone']['name']),
    'isbn' => $_POST['isbn'],
    'titre' => $_POST['titre'],
    'resume' => $_POST['resume']
  ));


}
if (isset($_POST['envoyer'])){
  $target_dir = "image/";
  $target_file = $target_dir . basename($_FILES["icone"]["name"]);
  if (move_uploaded_file($_FILES["icone"]["tmp_name"], $target_file)) {
      echo "The file ". basename( $_FILES["icone"]["name"]). " has been uploaded.";
  } else {
      echo "Sorry, there was an error uploading your file.";
  }
  echo ($_POST['auteur']);
  echo ($_POST['isbn']);
  echo ($_POST['titre']);
  echo ($_POST['resume']);
}
?>
