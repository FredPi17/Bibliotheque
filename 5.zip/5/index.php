<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bibliotheque | Accueil</title>
  <!-- Bootstrap -->
  <link href="style/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <link href="style/css/style.css" rel="stylesheet">
  <!--<link rel="stylesheet" href="style/bootstrap.min.css">-->

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<!-- /**Le jquery ne se trouve pas dans le download boot strap on est obligé de le récupérer enligne!*/-->
<script src="js/bootstrap.min.js"></script>
  <style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 70%; /**Règle ta taille de carrousel /a width*/
      margin: auto;
  }
  article {
    background-color: rgb(246,246,246);
  }
  #sommaire, aside{
    background-color: white;
    padding: 10px;
  }
  
  </style>
</head>
<body>


<?php
session_start();
include("include/outils.php");
include("include/livre.php");
include("include/utilisateur.php");
if (isset($_POST['inscription'])) {
  header('Location: inscription.php');
  die() ;
}
echo menuConnexion();
echo Index();
//echo Carrousel();

 ?>
<article>
  <h1>Présentation</h1>
  <div id="sommaire">
    <p>Présentation du projet</p><br /> <p>Présentation du contexte</p><br /><p>Présentation de la structure du site</p>
  </div>
  <aside>
    <h3>
    Dernieres sorties
    </h3>
    <div class="new"><div class="photo">photo</div><div class="resum"><p>Résumé, note</p></div></div>
    <div class="new"><div class="photo">photo</div><div class="resum"><p>Résumé, note</p></div></div>
    <div class="new"><div class="photo">photo</div><div class="resum"><p>Résumé, note</p></div></div>
    <div class="new"><div class="photo">photo</div><div class="resum"><p>Résumé, note</p></div></div>
  </aside>
</article>

<style>
  article{
    border: 1px solid black;
    height: 500px;
    margin-top: 2%;
    margin-bottom: 2%;
    margin-left: 5%;
    width: 90%;
  }
  h1{
    margin-left: 2%;
  }
  #sommaire{
    border: 1px solid black;
    height: 85%;
    width: 70%;
    margin-left: 2%;
  }

  aside{
    /*width: 20%;*/
    border: 1px solid black;
    height: 85%;
    float: right;
    margin-right: 5%;
    width: 20%;
  }
  .new {
    border: 1px solid black;
    margin-top: 2px;
    margin-bottom: 2px;
    width: 100%;
    height: 20%;
  }
  .photo{
    border: 1px solid black;
    width: 30%;
    height: 100%;
  }
  div.photo, div.resum{
    display: inline-block;
  }
  article, aside{
    display: inline-block;
  }
  #sommaire, aside{
    display: inline-block;
  }
</style>

<?php

echo piedPage();

?>

<style>
li{
  text-decoration-style: none;
  list-style: none;
  color: black;
}
.bot, p{
  display: inline-block;
}
footer{
  text-align: center;
  padding: 10px;
  background-color: orange;
}
.bot{
  display: inline-flex;
}
p{
  margin-bottom: : 10px;
}
</style>
